# Jibodu Akinbowale – Portfolio

Web designer and Shopify developer portfolio. Live site: enable GitHub Pages (Settings > Pages > Deploy from branch > main / root).
